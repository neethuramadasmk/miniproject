<!DOCTYPE html>
<html lang="en">
<?php
    include './conn1.php'; 
    session_start();
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
    $login_id=$_SESSION['id'];
    $sql1= mysqli_query($con, "SELECT * FROM `user` WHERE `log_id`=$login_id and status=1");
    $row1 = mysqli_fetch_array($sql1);
    $name=$row1['fname'];
?>
<head>
	
	<meta charset="utf-8">
	<title>Glammy | Furniture Store </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/favicon.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/fancySelect.css" rel="stylesheet" media="screen, projection" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
        
        <link href="css/mystyle.css" rel="stylesheet" type="text/css" />
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="../../../netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
        <script>
        function cPass(){
                var gl_new_pwd= document.gl_cp_form.gl_new_pwd.value;
                var gl_c_pwd=document.gl_cp_form.gl_c_pwd.value;
                
                if(gl_new_pwd.length < 4 || gl_c_pwd.length < 4 ){
                    document.gl_cp_form.gl_new_pwd.style.border = "1px solid red";
                    document.gl_cp_form.gl_new_pwd.focus();
                    alert("Password is Too Short");
                    return false;
                }
                if(gl_new_pwd !== gl_c_pwd){
                    document.gl_cp_form.gl_c_pwd.style.border = "1px solid red";
                    document.gl_cp_form.gl_c_pwd.focus();
                    alert("Mismatching Passwords");
                    return false;
                }
                var fpwd1=/^[a-z0-9]{4,25}$/;
                if(document.gl_cp_form.gl_c_pwd.value.search(fpwd1)==-1)
                 {
                      alert("Lowercase Letters,numbers(0-9) are allowed,Password Should not exceed 25 Characters");
                      document.gl_cp_form.gl_c_pwd.focus();
                      
                      return false;
                }
            }
        </script>
</head>
<body><?php
            if(isset($_POST["gl_cp_editbtn"])){
                function encryptIt($q){
                    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
                    $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
                    return( $qEncoded );
                }
                
                $pwd1= htmlspecialchars($_POST['gl_new_pwd']);
                
                
                $npwd = encryptIt($pwd1);
                $sql7="UPDATE `login` SET `password`='$npwd'"
                        . "WHERE `log_id`={$_SESSION['id']};";
                        
                echo $sql7;
                if (mysqli_query($con,$sql7) > 0){

                    echo "<script> alert('Password Changed Successfully'); </script>";
                ?>
                    <script>
                            window.location="changepassword.php";
                    </script>
                <?php
                }

                else{
                        echo "<script> alert ('Unsuccessfull !'); </script>";
                    }
                }
        ?>
<!-- PRELOADER -->
<div id="preloader"><img src="images/preloader.gif" alt="" /></div>
<!-- //PRELOADER -->
<div class="preloader_hide">

	<!-- PAGE -->
	<div id="page">
	
		<!-- HEADER -->
		<header>
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo">
                                            <a href="userhome.php" ><img src="images/logo.png" alt="" /></a>
					</div><!-- //LOGO -->
					
					
					
					<!-- MENU -->
					<ul class="navmenu center">
                                            <li class="sub-menu active"><a href="userhome.php" >Home</a>
						<li class="sub-menu first"><a href="changepassword.php" >Change Password</a>
							<!-- MEGA MENU -->
							
						</li>
						<li class="sub-menu"><a href="wallet.php" >Wallet</a>
							
						</li>
                                                <li class="sub-menu"><a href="cart.php" >Cart</a>
						</li>
                                                <li><a href="viewtransactions.php" >Transactions</a></li>
                                                	
						
						
						</li>
						<li class="last sale_menu"><a href="logout.php" >logout</a></li>
					</ul><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
		
		<!-- BREADCRUMBS -->
		<section class="breadcrumb women parallax margbot30">
			
			<!-- CONTAINER -->
			<div class="container">
                            <h2><?php echo $name; ?></h2>
			</div><!-- //CONTAINER -->
		</section><!-- //BREADCRUMBS -->
		
		
		<!-- SHOP BLOCK -->
		<section class="shop">
			
			<!-- CONTAINER -->
			<div class="container">
			
				<!-- ROW -->
				<div class="row">
					
					<!-- SIDEBAR -->
					<div id="sidebar" class="col-lg-3 col-md-3 col-sm-3 padbot50">
						
						<!-- CATEGORIES -->
                                                 <?php
                                                        $result =mysqli_query($con,"SELECT `category_id`, `c_name`, `img`, `status` FROM `category` where status=1 order by c_name;");
                                                        while (($t=mysqli_fetch_array($result))){
                                                            $cat_id=$t['category_id'];
                                                   ?>
						<div class="sidepanel widget_categories">
							<h3><?php  echo ucfirst($t['c_name']);  ?></h3>
							<ul>
                                                            <?php
                                                                 $result1 =mysqli_query($con,"SELECT * FROM `subcategory` where status=1 and category_id=$cat_id order by sub_cname;");
                                                                 while (($t1=mysqli_fetch_array($result1))){
                                                            ?>
                                                            <li><a href="category.php?sb_id=<?php  echo ucfirst($t1['subcategory_id']);  ?>" ><?php  echo ucfirst($t1['sub_cname']);  ?></a></li>
                                                            <?php
                                                                 }
                                                            ?>
                                                                
								
							</ul>
						</div><!-- //CATEGORIES -->
						<?php
                                                    }
                                               ?>
							
						
					</div><!-- //SIDEBAR -->
                                       
					
				</div><!-- //ROW -->
                                 <div class="gl_wallet_container">
                                   <form class="gl_reg_modal-content animate" id="gl_cp_form" name="gl_cp_form" action="#" onsubmit="return cPass()" method="POST" enctype="multipart/form-data" >
                    <div class="gl_form_container" align="center">
                        <h2 align="center" style="color: black;">Change Password</h2>
                        
                        <input type="password" placeholder="Enter New Password" name="gl_new_pwd"  id="gl_new_pwd" required>
                        <br/>
                        
                        <input type="password" placeholder="Confirm Password" name="gl_c_pwd" id="gl_c_pwd" required>
                        <br/>
                        <input type="submit"  name="gl_cp_editbtn" style="margin-right: 150px;" class="gl_reg_signupbtn" id="gl_cp_editbtn"   value="Change">
                           
                    </div>
                </form>
    </div>
    		</div><!-- //CONTAINER -->
               
	
		</section><!-- //SHOP -->
		
	
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.sticky.js" type="text/javascript"></script>
	<script src="js/parallax.js" type="text/javascript"></script>
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/jquery.jcarousel.js" type="text/javascript"></script>
	<script src="js/jqueryui.custom.min.html" type="text/javascript"></script>
	<script src="js/fancySelect.js"></script>
	<script src="js/animate.js" type="text/javascript"></script>
	<script src="js/myscript.js" type="text/javascript"></script>
	
</body>

<!-- Mirrored from demo.evatheme.com/html/glammy/women.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Aug 2017 08:04:41 GMT -->
</html>