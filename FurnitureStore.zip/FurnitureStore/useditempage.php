<!DOCTYPE html>
<html lang="en">
<?php
    include './conn1.php'; 
    session_start();
    
?><head>
	
	<meta charset="utf-8">
	<title>Glammy | Furniture Store </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/favicon.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/fancySelect.css" rel="stylesheet" media="screen, projection" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
        <link href="css/mystyle.css" rel="stylesheet" type="text/css" />
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="../../../netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	
</head>
<body>

<!-- PRELOADER -->
<div id="preloader"><img src="images/preloader.gif" alt="" /></div>
<!-- //PRELOADER -->
<div class="preloader_hide">

	<!-- PAGE -->
	<div id="page">
	
		<!-- HEADER -->
		<!-- HEADER -->
		<header>
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
                            <?php
                            if(isset($_SESSION['id'])){                            
                            ?>
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo">
                                            <a href="userhome.php" ><img src="images/logo.png" alt="" /></a>
					</div><!-- //LOGO -->
					
                                        <!-- MENU -->
					<!-- MENU -->
					<ul class="navmenu center">
                                            <li class="sub-menu active"><a href="userhome.php" >Home</a>
						<li class="sub-menu first"><a href="changepassword.php" >Change Password</a>
							<!-- MEGA MENU -->
							
						</li>
						<li class="sub-menu"><a href="wallet.php" >Wallet</a>
							
						</li>
                                                <li class="sub-menu"><a href="cart.php" >Cart</a>
						</li>
                                                <li><a href="viewtransactions.php" >Transactions</a></li>
                                                	
						
						<li class="sub-menu"><a href="javascript:void(0);" >Used Items</a>
							<!-- MEGA MENU -->
							<ul class="mega_menu megamenu_col1 clearfix">
								<li class="col">
									<ol>
										<li><a href="uitembuy.php" >Buy</a></li>
										<li><a href="uitemsell.php" >Sell</a></li>
									</ol>
								</li>
							</ul><!-- //MEGA MENU -->
						</li>
                                                <li><a href="notifications.php" >Notifications</a></li>
						<li class="last sale_menu"><a href="logout.php" >logout</a></li>
					</ul><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
                                <?php
                            }else{
                            ?>
                               <div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo">
                                            <a href="index.php" ><img src="images/logo.png" alt="" /></a>
					</div><!-- //LOGO -->
					
                                        <!-- MENU -->
					<ul class="navmenu center">
                                            <li class="sub-menu active"><a href="index.php" >Home</a>
							
                                            </li>
                                            
                                            <li class="sub-menu"><a href="javascript:void(0);" >Used Items</a>
							<!-- MEGA MENU -->
							<ul class="mega_menu megamenu_col1 clearfix">
								<li class="col">
									<ol>
										<li><a href="uitembuy.php" >Buy</a></li>
										<li><a href="uitemsell.php" >Sell</a></li>
									</ol>
								</li>
							</ul><!-- //MEGA MENU -->
						</li>
                                            <li class="last sale_menu"><a href="login.php" >Login</a></li>
					</ul><!-- //MENU -->
				</div><!-- //MENU BLOCK --> 
                               <?php
                            }
                            ?>  
                                
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
		
		<!-- BREADCRUMBS -->
		<section class="breadcrumb parallax margbot30"></section>
		<!-- //BREADCRUMBS -->
		
		
		<!-- TOVAR DETAILS -->
		<section class="tovar_details padbot70">
			
			<!-- CONTAINER -->
			<div class="container">
				
				<!-- ROW -->
				<div class="row">
					<?php
                                            $item_id=$_REQUEST['pid'];
                                            $sql55="SELECT * FROM `used_item` where status=2 and used_item_id=$item_id;";
                                            $sql1 =mysqli_query($con,$sql55);
                                             //echo $sql55;   
                                            $row1=mysqli_fetch_array($sql1);
                                                    $subcategory_id=$row1['subcategory_id'];
                                            $sql56="SELECT * FROM `subcategory` where status=1 and subcategory_id=$subcategory_id";
                                            $sql5 =mysqli_query($con,$sql56);
                                                $row5=mysqli_fetch_array($sql5);        
                                        ?>
					<!-- TOVAR DETAILS WRAPPER -->
					<div class="col-lg-9 col-md-9 tovar_details_wrapper clearfix">
						<div class="tovar_details_header clearfix margbot35">
							<h3 class="pull-left"><b><?php echo ucfirst($row5['sub_cname']);  ?></b></h3>
							
						</div>
						
						<!-- CLEARFIX -->
						<div class="clearfix padbot40">
							<div class="tovar_view_fotos clearfix">
								<div id="slider2" class="flexslider">
									<ul class="slides">
										<li><a href="javascript:void(0);" ><img src="<?php echo $row1['img'];  ?>" alt="" /></a></li>
										</ul>
								</div>
								
							</div>
							<div class="tovar_view_description">
                                                            <div class="tovar_view_title"><?php echo ucfirst($row1['used_item_name']);  ?></div>
								<div class="tovar_article">88-305-676</div>
								<div class="clearfix tovar_brend_price">
                                                                    <div class="pull-left tovar_brend">In Stock</div><br>
                                                                        <div class="pull-right tovar_view_price">$<?php echo $row1['price'];  ?></div>
								</div>
								
                                                    <form action="" method="POST">
								<div class="tovar_view_btn">
                                                                    <input type="text" name="gl_req_quantity" id="gl_req_quantity" placeholder="One" ><br/>
                                                                    <input type="text" name="gl_price" id="gl_price" value=" <?php echo $row1['price']; ?>" readonly><br/>
                                                                    <input type="text" name="gl_total" id="gl_total" Required readonly value=" <?php echo $row1['price']; ?>" ><br/>
                                                                    <input type="hidden" name="gl_log_id" value="<?php echo $row1['log_id']; ?>">
                                                                    <input type="submit" style="margin-right: 177px" value="BUY" name="cart"/>
								</div>
								</form>
							</div>
                                                    
                                                        <?php
                                                            if(isset($_POST["cart"])){
                                                                 
                                                                if(!isset($_SESSION['id'])){
                                                                    echo "<script>window.location.href='login.php'</script>";
                                                                }else{
                                                                
                                                                $price=htmlspecialchars($_POST['gl_price']);
                                                                $log_id=$_SESSION['id'];
                                                                $sellrid=htmlspecialchars($_POST['gl_log_id']);
                                                                
                                                                $sql21=mysqli_query($con,"select * from wallet where log_id=$log_id and status=1" );
                                                                $records21= mysqli_fetch_array($sql21);
                                                                $buyer_balance=$records21['balance'];
                                                                
                                                                if($price > $buyer_balance){
                                                                    echo "<script>alert('Insufficient Balance');</script>";
                                                                }else{
                                                                    $sql22=mysqli_query($con,"select * from wallet where log_id=$sellrid and status=1" );
                                                                    $records22= mysqli_fetch_array($sql22);
                                                                    $seller_balance=$records22['balance'];
                                                                    $new_sbal= $seller_balance +  $price;
                                                                    $new_bbal=$buyer_balance - $price;
                                                                    
                                                                    
                                                                    $sql123="UPDATE `used_item` SET status=0 WHERE used_item_id=$item_id and status=2 and log_id=$sellrid;";
                                                                    $result123=mysqli_query($con,$sql123);
                                                                    //echo $sql123;
                                                                    
                                                                    $sql124="UPDATE `wallet` SET balance=$new_sbal WHERE log_id=$sellrid and status=1;";
                                                                    $result124=mysqli_query($con,$sql124);
                                                                   // echo $sql124;
                                                                    
                                                                    $sql125="UPDATE `wallet` SET balance=$new_bbal WHERE log_id=$log_id and status=1;";
                                                                    $result125=mysqli_query($con,$sql125);
                                                                    //echo $sql125;
                                                                    
                                                                    $msg= "Your Product {$row1['used_item_name']} is Purchased by the User with ID: {$log_id} and Your new Balnce is {$new_sbal}";
                                                                    //echo $msg;
                                                                    
                                                                    $sql26="INSERT INTO `notification`(`message`,log_id,`status`) VALUES('$msg',$sellrid,1);";
                                                                    if (mysqli_query($con,$sql26) > 0){
                                                                    ?>
                                                                        <script>
                                                                                window.location.href="userhome.php";
                                                                                alert("Success");
                                                                        </script>

                                                        <?php
                                                                    }
                                                                    }
                                                                }
                                                            }
                                                        ?>
                                                    
						</div><!-- //CLEARFIX -->
						
						<!-- TOVAR INFORMATION -->
						<div class="tovar_information">
							<ul class="tabs clearfix">
								<li class="current">Details</li>
								<li>Information</li>
								<li>Reviews (2)</li>
							</ul>
                                                    <div class="box visible">
                                                        <p><?php echo $row1['description'];  ?></p>
                                                    </div>
							<div class="box">
                                                                Name: <?php echo ucfirst($row1['item_name']);  ?>  <br>
								Price:$<?php echo $row1['price'];  ?>  <br>
                                                                
                                                                In Stock<br>
								
								Size Details:<br>
								All sizes from Normal<br>
								Size include Large,Big,Small Furnitures
							</div>
							<div class="box">
								<ul class="comments">
									<li>
										<div class="clearfix">
											<p class="pull-left"><strong><a href="javascript:void(0);" >John Doe</a></strong></p>
											<span class="date">2013-10-09 09:23</span>
											<div class="pull-right rating-box clearfix">
												<i class="fa fa-star"></i>
												<i class="fa fa-star"></i>
												<i class="fa fa-star"></i>
												<i class="fa fa-star-o"></i>
												<i class="fa fa-star-o"></i>
											</div>
										</div>
										<p>Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit. Aenean auctor wisi et urna. Aliquam erat volutpat. Duis ac turpis. Integer rutrum ante eu lacus.Vestibulum libero nisl, porta vel, scelerisque eget, malesuada at, neque.</p>
									</li>
									<li>
										<div class="clearfix">
											<p class="pull-left"><strong><a href="javascript:void(0);" >John Doe</a></strong></p>
											<span class="date">2013-10-09 09:23</span>
											<div class="pull-right rating-box clearfix">
												<i class="fa fa-star"></i>
												<i class="fa fa-star"></i>
												<i class="fa fa-star"></i>
												<i class="fa fa-star"></i>
												<i class="fa fa-star"></i>
											</div>
										</div>
										<p>Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit. Aenean auctor wisi et urna. Aliquam erat volutpat. Duis ac turpis. Integer rutrum ante eu lacus.Vestibulum libero nisl, porta vel, scelerisque eget, malesuada at, neque.</p>
										
										<ul>
											<li>
												<p><strong><a href="javascript:void(0);" >Jane Doe</a></strong></p>
												<p>Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit. Aenean auctor wisi et urna. Aliquam erat volutpat. Duis ac turpis. Integer rutrum ante eu lacus.Vestibulum libero nisl, porta vel, scelerisque eget, malesuada at, neque.</p>
											</li>
										</ul>
									</li>
								</ul>
								
								<h3>WRITE A REVIEW</h3>
								<p>Now please write a (short) review....(min. 200, max. 2000 characters)</p>
								<div class="clearfix">
									<textarea id="review-textarea"></textarea>
									<label class="pull-left rating-box-label">Your Rate:</label>
									<div class="pull-left rating-box clearfix">
										<i class="fa fa-star-o"></i>
										<i class="fa fa-star-o"></i>
										<i class="fa fa-star-o"></i>
										<i class="fa fa-star-o"></i>
										<i class="fa fa-star-o"></i>
									</div>
									<input type="submit" class="dark-blue big" value="Submit a review">
								</div>
							</div>
						</div><!-- //TOVAR INFORMATION -->
					</div><!-- //TOVAR DETAILS WRAPPER -->
				</div><!-- //ROW -->
			</div><!-- //CONTAINER -->
		</section><!-- //TOVAR DETAILS -->
		
		
		<!-- BANNER SECTION -->
		<section class="banner_section">
			
			<!-- CONTAINER -->
			<div class="container">
				
				<!-- ROW -->
				<div class="row">
					
					<!-- BANNER WRAPPER -->
					<div class="banner_wrapper">
						<!-- BANNER -->
						<div class="col-lg-9 col-md-9">
							<a class="banner type4 margbot40" href="javascript:void(0);" ><img src="images/tovar/banner4.jpg" alt="" /></a>
						</div><!-- //BANNER -->
						
						<!-- BANNER -->
						<div class="col-lg-3 col-md-3">
							<a class="banner nobord margbot40" href="javascript:void(0);" ><img src="images/tovar/banner5.jpg" alt="" /></a>
						</div><!-- //BANNER -->
					</div><!-- //BANNER WRAPPER -->
				</div><!-- //ROW -->
			</div><!-- //CONTAINER -->
		</section><!-- //BANNER SECTION -->
		
		
		<!-- NEW ARRIVALS -->
		<section class="new_arrivals padbot50">
			
			<!-- CONTAINER -->
			<div class="container">
				<h2>new arrivals</h2>
				
				<!-- JCAROUSEL -->
				<div class="jcarousel-wrapper">
					
					<!-- NAVIGATION -->
					<div class="jCarousel_pagination">
						<a href="javascript:void(0);" class="jcarousel-control-prev" ><i class="fa fa-angle-left"></i></a>
						<a href="javascript:void(0);" class="jcarousel-control-next" ><i class="fa fa-angle-right"></i></a>
					</div><!-- //NAVIGATION -->
					
					<div class="jcarousel">
						<ul>
                                                    <?php
                                                    $sql2 =mysqli_query($con,"SELECT * FROM `used_item` where status=2 and subcategory_id=$subcategory_id order by date desc;");
                                                        while(($row2=mysqli_fetch_array($sql2))){
                                                    ?>
							<li>
								<!-- TOVAR -->
								<div class="tovar_item_new">
									<div class="tovar_img">
										<img src="<?php echo $row2['img']; ?>" alt="" />
										</div>
									<div class="tovar_description clearfix">
                                                                            <a class="tovar_title" href="useditempage.php?pid=<?php echo $row2['used_item_id']; ?>" ><?php echo ucfirst($row2['used_item_name']); ?></a>
										<span class="tovar_price">$<?php echo $row2['price']; ?></span>
									</div>
								</div><!-- //TOVAR -->
							</li>
							<?php
                                                        }
                                                        ?>
						</ul>
					</div>
				</div><!-- //JCAROUSEL -->
			</div><!-- //CONTAINER -->
		</section><!-- //NEW ARRIVALS -->
		
		
	
		
	</div><!-- //PAGE -->
</div>

<!-- TOVAR MODAL CONTENT -->
<div id="modal-body" class="clearfix">
	<div id="tovar_content"></div>
	<div class="close_block"></div>
</div><!-- TOVAR MODAL CONTENT -->

	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.sticky.js" type="text/javascript"></script>
	<script src="js/parallax.js" type="text/javascript"></script>
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/jquery.jcarousel.js" type="text/javascript"></script>
	<script src="js/fancySelect.js"></script>
	<script src="js/animate.js" type="text/javascript"></script>
	<script src="js/myscript.js" type="text/javascript"></script>
    
	
</body>

<!-- Mirrored from demo.evatheme.com/html/glammy/product-page.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Aug 2017 08:03:28 GMT -->
</html>