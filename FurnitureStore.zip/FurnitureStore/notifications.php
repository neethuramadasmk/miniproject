<!DOCTYPE html>
<html lang="en">
<?php
    include './conn1.php'; 
    session_start();
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
    $login_id=$_SESSION['id'];
    $sql1= mysqli_query($con, "SELECT * FROM `user` WHERE `log_id`=$login_id and status=1");
    $row1 = mysqli_fetch_array($sql1);
    $name=$row1['fname'];
?>
<head>
	
	<meta charset="utf-8">
	<title>Glammy | Furniture Store </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/favicon.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/fancySelect.css" rel="stylesheet" media="screen, projection" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="../../../netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	
</head>
<style>
    div.img {
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    width: 180px;
	background-color:lightgoldenrodyellow;
	height:290px;
	border-radius:13px 13px 13px 13px;
}
div.img:hover span:after {
  position: relative;
  opacity: 0;
  top: 0;
  left:980px;
  transition: 0.5s;
}



div.img:hover span{
    border: 1px solid #777;
	padding-right: 0px;
}

div.img:hover span:after{
  opacity: 1;
  right: 0;
}

div.img img {
    height:200px;
	width:190px;
}

div.desc {
    padding: 15px;
    text-align: center;
	font-family:Benguiat Bk BT;
}
.button1 {	width:100px;
	background-color:#33FF99;
	border-radius:13px;
	cursor: pointer;
}

</style>
<body>

<!-- PRELOADER -->
<div id="preloader"><img src="images/preloader.gif" alt="" /></div>
<!-- //PRELOADER -->
<div class="preloader_hide">

	<!-- PAGE -->
	<div id="page">
	
		<!-- HEADER -->
		<header>
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo">
                                            <a href="userhome.php" ><img src="images/logo.png" alt="" /></a>
					</div><!-- //LOGO -->
					
					
					
					<!-- MENU -->
					<ul class="navmenu center">
                                            <li class="sub-menu active"><a href="userhome.php" >Home</a>
						<li class="sub-menu first"><a href="changepassword.php" >Change Password</a>
							<!-- MEGA MENU -->
							
						</li>
						<li class="sub-menu"><a href="wallet.php" >Wallet</a>
							
						</li>
                                                <li class="sub-menu"><a href="cart.php" >Cart</a>
						</li>
                                                <li><a href="viewtransactions.php" >Transactions</a></li>
                                                	
						
						<li class="sub-menu"><a href="javascript:void(0);" >Used Items</a>
							<!-- MEGA MENU -->
							<ul class="mega_menu megamenu_col1 clearfix">
								<li class="col">
									<ol>
										<li><a href="uitembuy.php" >Buy</a></li>
										<li><a href="uitemsell.php" >Sell</a></li>
									</ol>
								</li>
							</ul><!-- //MEGA MENU -->
						</li>
                                                <li><a href="notifications.php" >Notifications</a></li>
						<li class="last sale_menu"><a href="logout.php" >logout</a></li>
					<!--</ul> //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
		
		<!-- BREADCRUMBS -->
		<section class="breadcrumb women parallax margbot30">
			
			<!-- CONTAINER -->
			<div class="container">
                            <h2><?php echo $name; ?></h2>
			</div><!-- //CONTAINER -->
		</section><!-- //BREADCRUMBS -->
		
		
		<!-- SHOP BLOCK -->
		<section class="shop">
			
			<!-- CONTAINER -->
			<div class="container">
			
				<!-- ROW -->
				<div class="row">
                                    <div class="gl_userhome_container" name="gl_userhome_container">
                                        <?php
                                           $qry3="SELECT `n_id`, `message`, `log_id`, DATE(date) as date, `status` FROM `notification` WHERE log_id=".$_SESSION['id']." and status=1 order by date desc;";
                                         //  echo $qry3;
                                           $sql3=mysqli_query($con,$qry3);
                                            if($sql3){    
                                            while($records3=mysqli_fetch_array($sql3)){
                                                    
                                        ?>
                                                <div class="gl_item_container">
                                                    <center>
                                                    <table cellpadding="8px" style="font-size:20px;" >
                                                                <tr>
                                                                    <td>
                                                                        <b>Admin Team</b>
                                                                    </td>
                                                                    <td>
                                                                        Date:<?php echo "{$records3['date']}"; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <?php echo "{$records3['message']}"; ?>
                                                                    </td>
                                                                
                                                                </tr>
                                                                
                                                    </table>
                                                    </center>
                                                    <hr/>
                                                </div>
                                                    <?php
                                                }
                                            }   
                                        ?>
                                        </div>
			
				</div><!-- //ROW -->
			</div><!-- //CONTAINER -->
		</section><!-- //SHOP -->
		
	
		
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.sticky.js" type="text/javascript"></script>
	<script src="js/parallax.js" type="text/javascript"></script>
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/jquery.jcarousel.js" type="text/javascript"></script>
	<script src="js/jqueryui.custom.min.html" type="text/javascript"></script>
	<script src="js/fancySelect.js"></script>
	<script src="js/animate.js" type="text/javascript"></script>
	<script src="js/myscript.js" type="text/javascript"></script>
	
</body>

<!-- Mirrored from demo.evatheme.com/html/glammy/women.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Aug 2017 08:04:41 GMT -->
</html>