<?php
    include './conn1.php'; 
    session_start();
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
    ?>
<div class="tover_view_page element_fade_in">
	<div class="tover_view_header clearfix">
		<p>Quick view</p>
		<a id="tover_view_page_close" href="javascript:void(0);">Close<i>X</i></a>
	</div>
	<?php
            $item_id=$_REQUEST['pid'];
            
            $abcd="SELECT * FROM `items` where status=1 and item_id=$item_id;";
            $sql1 =mysqli_query($con,$abcd);
                $row1=mysqli_fetch_array($sql1);
                    $subcategory_id=$row1['subcategory_id'];
        ?>
	<div class="clearfix">
		<div class="tovar_view_fotos clearfix">
			<div id="slider1" class="flexslider">
				<ul class="slides">
					<li><a href="javascript:void(0);" ><img src="<?php echo $row1['img'];  ?>" alt="" /></a></li>
				</ul>
			</div>
			
		</div>
		
		<div class="tovar_view_description">
			<div class="tovar_view_title"><?php  echo ucfirst($t['c_name']);  ?></div>
			<div class="tovar_article">88-305-676</div>
			<div class="clearfix tovar_brend_price">
				<div class="pull-left tovar_brend">In Stock</div>
				<div class="pull-right tovar_view_price">$<?php echo $row1['price'];  ?></div>
			</div>
			
			<div class="tovar_view_btn">
				<select class="basic">
					<option value="">QTY</option>
					<option>Lo</option>
					<option>Ips</option>
					<option>Dol</option>
					<option>Sit</option>
					<option>Amet</option>
				</select>
				<a class="add_bag" href="javascript:void(0);" ><i class="fa fa-shopping-cart"></i>Add to bag</a>
				
			</div>
			<div class="tovar_shared clearfix">
				<p>Share item with friends</p>
				<ul>
					<li><a class="facebook" href="javascript:void(0);" ><i class="fa fa-facebook"></i></a></li>
					<li><a class="twitter" href="javascript:void(0);" ><i class="fa fa-twitter"></i></a></li>
					<li><a class="linkedin" href="javascript:void(0);" ><i class="fa fa-linkedin"></i></a></li>
					<li><a class="google-plus" href="javascript:void(0);" ><i class="fa fa-google-plus"></i></a></li>
					<li><a class="tumblr" href="javascript:void(0);" ><i class="fa fa-tumblr"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>


























