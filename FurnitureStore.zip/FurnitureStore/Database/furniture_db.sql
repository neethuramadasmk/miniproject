-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2018 at 07:00 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `furniture_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `c_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `qty` int(4) NOT NULL,
  `total_price` int(7) NOT NULL,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`c_id`, `log_id`, `item_id`, `date`, `qty`, `total_price`, `status`) VALUES
(1, 1, 1, '2018-01-26 06:37:50', 3, 26700, 0),
(2, 1, 2, '2018-01-26 06:42:47', 1, 7500, 0),
(3, 3, 1, '2018-01-26 08:28:33', 2, 17800, 0),
(4, 3, 1, '2018-01-26 11:41:04', 1, 8900, 1),
(5, 4, 1, '2018-01-27 05:46:30', 1, 9900, 0),
(6, 4, 4, '2018-01-27 05:48:40', 1, 15000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `c_name` varchar(30) NOT NULL,
  `img` varchar(100) NOT NULL,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `c_name`, `img`, `status`) VALUES
(1, 'living room', 'Category/1516894101livingroom.jpg', 1),
(2, 'dining room', 'Category/1516894587dining.jpg', 1),
(3, 'bed room', 'Category/1517023203bedrrom.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `price` int(7) NOT NULL,
  `stock` int(7) NOT NULL,
  `description` varchar(600) NOT NULL,
  `img` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_name`, `subcategory_id`, `price`, `stock`, `description`, `img`, `category_id`, `date`, `status`) VALUES
(1, 'Montoya office chair', 2, 9900, 99, 'Confortable Chair with automatic pushback', 'Items/1516900257montoya.jpg', 1, '2018-01-26 03:26:42', 1),
(2, 'Valley office chair', 2, 7500, 100, 'Solid Push back Beaautiful Chair', 'Items/1516900457valley.png', 1, '2018-01-26 03:26:42', 1),
(3, 'modern sofa sets', 1, 100000, 4, 'Royal High Quality Stylish Sofa set with a Classy Finish', 'Items/1517023097livingsofa1.jpg', 1, '2018-01-27 03:18:17', 1),
(4, 'duetto bed', 3, 15000, 19, 'Royal Classic Finish Bed give you extra comfort and Lots of Enjoyment. High Quality Wood is used', 'Items/1517023779duetto.jpg', 3, '2018-01-27 03:29:39', 1),
(5, 'norman storage bed', 3, 14500, 20, 'This bed Comes with extra storage Capacity. Best in its class.', 'Items/1517023886norman.jpg', 3, '2018-01-27 03:31:26', 1),
(6, 'cavinity storage single bed', 4, 12000, 40, 'Compared to its Size this bed has Huge Volume of Storage space and Its very comfortable', 'Items/1517024081cavvv.jpg', 3, '2018-01-27 03:34:41', 1),
(7, 'glassy six seat table', 6, 25750, 52, 'Modern looking Dining Table with a glassy finish. Stunning Looks', 'Items/1517024247glass.jpg', 2, '2018-01-27 03:37:27', 1),
(8, 'arabian  six seat table', 6, 85600, 85, 'Arabian Royal Six Seat Dining table. ', 'Items/1517024335arab.jpg', 2, '2018-01-27 03:38:55', 1);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `log_id` int(11) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `utype` varchar(3) NOT NULL,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`log_id`, `uname`, `password`, `utype`, `status`) VALUES
(1, 'neethu', 'fPCOcTBGzhrKyLtFoMyFJQruWkBxgQfifIwQnIeTe80=', 'U', 1),
(2, 'admin', 'g97Jt2cpGmsJfUK0EeMFmd9CBsXy6MN5d3Q+MXmlu3s=', 'A', 1),
(3, 'nirmal', 'tlT/fDs/qn19VwKPEDy+UiKIUKQO84u4dU4ND3dxhAc=', 'U', 1),
(4, 'jibin', 'fPCOcTBGzhrKyLtFoMyFJQruWkBxgQfifIwQnIeTe80=', 'U', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `n_id` int(11) NOT NULL,
  `message` varchar(200) NOT NULL,
  `log_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`n_id`, `message`, `log_id`, `date`, `status`) VALUES
(2, 'Your Product synthetic washable chair is Purchased by the User with ID: 1 and Your new Balnce is 485200', 3, '2018-01-26 16:54:00', 1),
(3, 'Your Product synthetic washable chair is Purchased by the User with ID: 3 and Your new Balnce is 485950', 3, '2018-01-26 17:53:17', 1),
(4, 'Your Product synthetic washable chair is Purchased by the User with ID: 3 and Your new Balnce is 485200', 3, '2018-01-26 17:55:10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pay_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `w_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(5) NOT NULL,
  `amount` int(8) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pay_id`, `log_id`, `w_id`, `item_id`, `qty`, `amount`, `date`, `status`) VALUES
(1, 1, 1, 1, 3, 26700, '2018-01-26 07:41:37', 1),
(2, 1, 1, 2, 1, 7500, '2018-01-26 07:41:38', 1),
(3, 3, 3, 1, 2, 17800, '2018-01-26 08:28:47', 1),
(4, 4, 4, 1, 1, 9900, '2018-01-27 05:46:53', 1),
(5, 4, 4, 4, 1, 15000, '2018-01-27 05:48:46', 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `pur_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `pay_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`pur_id`, `log_id`, `item_id`, `pay_id`, `qty`, `date`, `status`) VALUES
(1, 1, 1, 0, 3, '2018-01-26 07:41:38', 1),
(2, 1, 2, 0, 1, '2018-01-26 07:41:38', 1),
(3, 3, 1, 0, 2, '2018-01-26 08:28:47', 1),
(4, 4, 1, 0, 1, '2018-01-27 05:46:53', 1),
(5, 4, 4, 0, 1, '2018-01-27 05:48:46', 1);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `subcategory_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_cname` varchar(30) NOT NULL,
  `img` varchar(100) NOT NULL,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`subcategory_id`, `category_id`, `sub_cname`, `img`, `status`) VALUES
(1, 1, 'sofa', 'Subcategory/1516896086sofa.jpg', 1),
(2, 1, 'chair', 'Subcategory/1516897067chair.jpg', 1),
(3, 3, 'double beds', 'Subcategory/1517023333double.jpg', 1),
(4, 3, 'single bed', 'Subcategory/1517023387singlebed.jpg', 1),
(5, 2, 'eight seat', 'Subcategory/1517023488eseat.jpg', 1),
(6, 2, 'six seat', 'Subcategory/1517023598sixseat.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `used_item`
--

CREATE TABLE `used_item` (
  `used_item_id` int(11) NOT NULL,
  `used_item_name` varchar(30) NOT NULL,
  `log_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `price` int(8) NOT NULL,
  `age` int(4) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `wood_id` int(11) NOT NULL,
  `img` varchar(100) NOT NULL,
  `description` varchar(600) NOT NULL,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `used_item`
--

INSERT INTO `used_item` (`used_item_id`, `used_item_name`, `log_id`, `category_id`, `subcategory_id`, `price`, `age`, `date`, `wood_id`, `img`, `description`, `status`) VALUES
(1, 'synthetic washable chair', 3, 1, 2, 750, 12, '2018-01-26 15:06:41', 1, 'Items/1516979201usedchair.jpg', 'Good Quality Washable Chair with Stunning Looks', 1),
(2, 'wooden chair', 3, 1, 2, 1000, 24, '2018-01-26 15:11:38', 1, 'Items/1516979498woodused.jpg', 'Its Royal Wooden Chair with Classic Finish', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `log_id` int(11) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(80) NOT NULL,
  `housename` varchar(100) NOT NULL,
  `city` varchar(80) NOT NULL,
  `district` varchar(30) NOT NULL,
  `pin` int(10) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`log_id`, `fname`, `lname`, `gender`, `phone`, `email`, `housename`, `city`, `district`, `pin`, `uname`, `status`) VALUES
(1, 'Neethu', 'Das', 'f', '8943074070', 'neethu@gmail.com', 'Koovakkal', 'Pala', 'Kottayam', 670721, 'neethu', 1),
(3, 'Niirmal', 'Unnikrishnan', 'm', '8943074070', 'nirmalku@mca.ajce.in', 'Nirmallyam', 'Panamaram', 'Wayanad', 670721, 'nirmal', 1),
(4, 'Jibin', 'Baby', 'm', '8943074070', 'jibinbaby@mca.ajce.in', 'Koovakkal', 'Kanjirappally', 'Wayanad', 670721, 'jibin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wallet`
--

CREATE TABLE `wallet` (
  `w_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `bank_name` varchar(30) NOT NULL,
  `balance` int(11) NOT NULL,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wallet`
--

INSERT INTO `wallet` (`w_id`, `log_id`, `bank_name`, `balance`, `status`) VALUES
(1, 1, 'Federal Bank', 95300, 1),
(2, 2, 'SBI', 145300, 1),
(3, 3, 'Federal Bank', 483700, 1),
(4, 4, 'SBI', 50100, 1);

-- --------------------------------------------------------

--
-- Table structure for table `woodtype`
--

CREATE TABLE `woodtype` (
  `wood_id` int(11) NOT NULL,
  `w_name` varchar(30) NOT NULL,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `woodtype`
--

INSERT INTO `woodtype` (`wood_id`, `w_name`, `status`) VALUES
(1, 'Mahogany', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `c_name` (`c_name`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`pur_id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`subcategory_id`);

--
-- Indexes for table `used_item`
--
ALTER TABLE `used_item`
  ADD PRIMARY KEY (`used_item_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `wallet`
--
ALTER TABLE `wallet`
  ADD PRIMARY KEY (`w_id`);

--
-- Indexes for table `woodtype`
--
ALTER TABLE `woodtype`
  ADD PRIMARY KEY (`wood_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `n_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `pur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `subcategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `used_item`
--
ALTER TABLE `used_item`
  MODIFY `used_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `wallet`
--
ALTER TABLE `wallet`
  MODIFY `w_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `woodtype`
--
ALTER TABLE `woodtype`
  MODIFY `wood_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
