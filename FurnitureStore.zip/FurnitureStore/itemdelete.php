<?php
    session_start();  
    include './conn1.php';
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
    $id=$_REQUEST['id'];
    $sql="update used_item set status=3 where used_item_id='$id'";
//    echo $sql;
    $results=mysqli_query($con,$sql);
    if($results>0)
        {
?>
            <script>
                    window.location="viewdeleteditems.php";
                    alert("Deleted");
            </script>

<?php
        }
        else{
            echo "can not delete";
            header("location:viewuseditems.php");
        }
?>

