<!DOCTYPE html>
<html lang="en">
<?php
    include './conn1.php'; 
    session_start();
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
?>
<head>
	
	<meta charset="utf-8">
	<title>Glammy | Furniture Store </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/favicon.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/fancySelect.css" rel="stylesheet" media="screen, projection" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
        <link href="css/mystyle.css" rel="stylesheet" type="text/css" />
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
        <link href="../../../netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
        <script>
            $(window).load(function () {
                $('.slider')._TMS({
                    show: 0,
                    pauseOnHover: false,
                    prevBu: '.prev',
                    nextBu: '.next',
                    playBu: false,
                    duration: 800,
                    preset: 'fade',
                    pagination: true, //'.pagination',true,'<ul></ul>'
                    pagNums: false,
                    slideshow: 8000,
                    numStatus: false,
                    banners: true,
                    waitBannerAnimation: false,
                    progressBar: false
                })
            });
            $(window).load(function () {
                $('.carousel1').carouFredSel({
                    auto: false,
                    prev: '.prev',
                    next: '.next',
                    width: 960,
                    items: {
                        visible: {
                            min: 3,
                            max: 3
                        },
                        height: 'auto',
                        width: 300,
                    },
                    responsive: true,
                    scroll: 1,
                    mousewheel: false,
                    swipe: {
                        onMouse: true,
                        onTouch: true
                    }
                });
            });
            jQuery(document).ready(function () {
                $().UItoTop({
                    easingType: 'easeOutQuart'
                });
            });
</script>
    
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: right;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color: #111;
}

.active {
    background-color: #4CAF50;
}
.select{
	width:160px;
	height:20px;
	background-color:#333;
	 display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
	border-radius:13px;
}


div.img {
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    width: 180px;
	background-color:lemonchiffon;
	height:290px;
	border-radius:13px 13px 13px 13px;
}
div.img:hover span:after {
  position: relative;
  opacity: 0;
  top: 0;
  left:980px;
  transition: 0.5s;
}



div.img:hover span{
    border: 1px solid #777;
	padding-right: 0px;
}

div.img:hover span:after{
  opacity: 1;
  right: 0;
}

div.img img {
    height:200px;
	width:190px;
}

div.desc {
    padding: 15px;
    text-align: center;
	font-family:Benguiat Bk BT;
}
.button1 {	width:100px;
	background-color:#33FF99;
	border-radius:13px;
	cursor: pointer;
}

</style>
</head>
<body>

<!-- PRELOADER -->
<div id="preloader"><img src="images/preloader.gif" alt="" /></div>
<!-- //PRELOADER -->
<div class="preloader_hide">

	<!-- PAGE -->
	<div id="page">
	
		<!-- HEADER -->
		<header>
                    <div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo">
						<a href="userhome.php" ><img src="images/logo.png" alt="" /></a>
					</div><!-- //LOGO -->
					
					
					<!-- SEARCH FORM -->
					<div class="top_search_form">
						<a class="top_search_btn" href="javascript:void(0);" ><i class="fa fa-search"></i></a>
						<form method="get" action="#">
							<input type="text" name="search" value="Search" onFocus="if (this.value == 'Search') this.value = '';" onBlur="if (this.value == '') this.value = 'Search';" />
						</form>
					</div><!-- SEARCH FORM -->
					
					
					
					
					
					
					
					
					<!-- MENU -->
					<ul class="navmenu center">
                                                <li class="sub-menu active"><a href="logout.php" >Log Out</a>	
						<li class="sub-menu active"><a href="userhome.php" >Home</a>
						
						</li>
						
						
						
					</ul><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
		
		<!-- BREADCRUMBS -->
		<section class="breadcrumb women parallax margbot30">
			
			<!-- CONTAINER -->
			<div class="container">
				<h2>SHOP NOW</h2>
			</div><!-- //CONTAINER -->
		</section><!-- //BREADCRUMBS -->
		
		
		<!-- SHOP BLOCK -->
		<section class="shop">
			<form  action="#" method="POST">	
                            <br />
                            <select name="gl_item_category" id="gl_item_category" required style="width:30%;">
                                <?php
                                    $sql="Select category_id,c_name from category Order By c_name;";
                                    $rset=mysqli_query($con,$sql);
                                    $records=mysqli_fetch_array($sql);
                                    echo "<option value=''>Select a Category</option>";
                                    foreach($rset as $records){

                                        echo "<option value='{$records["category_id"]}'>{$records["c_name"]}  </option>";

                                    }
                                 ?>
                            </select>
                            <br/>
                            <select name="gl_item_sub_category" id="gl_item_sub_category" required="" style="width:30%;">

                            </select>
                            <input type="submit" name="submit">
                        </form>
                          
                        <center>
                        <table><?php 
                        if(isset($_POST['submit']))
                        {
                            $sbc=$_POST['gl_item_sub_category'];
                            $abc=$_POST['gl_item_category'];
                            $qry2="SELECT `subcategory_id` FROM `subcategory` WHERE `sub_cname`='$sbc'";
                            $res2=mysqli_query($con,$qry2);
                            $ar2=mysqli_fetch_array($res2);
                            $f=$ar2['subcategory_id'];
                            $qry="select * from items WHERE `subcategory_id`='$f' and category_id='$abc'";
                            $res=mysqli_query($con,$qry);
                            $i=0;
                            while($ar=mysqli_fetch_array($res))
                            {
                                $i++;
                                if($i % 6==1)
                                {
                                        echo "<tr>";
                                }
                        ?>
                                <td>
                                                <!-- <form action="book.php" method="post"> -->
                                    <div class="img">
                                        <span><img src="<?php echo $ar['img']?>" alt="Trolltunga Norway"></span>
                                            <div class="desc">
                                                <br><?php echo $ar['description']?>
                                                    <br><?php echo $ar['price']?><br>
                                                        <input type="hidden" value="<?php echo $ar['item_id']?>" name="pid" />
                                            <a href="itempage.php?pid=<?php echo $ar['item_id']; ?>" ><button type="submit" value="More Details1" name="submit" class="button1"/>More Details</button>
                                           </a>
                                            </div>
                                    </div>
                                   <!-- </form> -->
                                </td>
                        <?php } 
                         }
                         else
                        {

                        $query="select * from items";
                        $result=mysqli_query($con,$query);
                        $i=0;
                        while($array=mysqli_fetch_array($result))
                        {
                                $i++;
                                if($i % 6==1)
                                {
                                        echo "<tr>";
                                }
                        ?>
                                <td>
                                                <!-- <form action="petdetails.php" method="post"> -->
                                        <div class="img">
                                                        <span><img src="<?php echo $array['img']?>" alt="Trolltunga Norway"></span>
                                                        <div class="desc">


                                                                 <br><?php echo $array['description']?>
                                                                 <br><?php echo $array['price']?><br>
                                                                <input type="hidden" value="<?php echo $array['item_id']?>" name="pid" />
                                            <a href="itempage.php?pid=<?php echo $array['item_id']; ?>" ><button type="submit" value="More Details" name="submit" class="button1"/>More Details</button></a>
                                                         </div>
                                                </div>
                                 <!--  </form> -->
                                        </td>
                         <?php } 
                         }
                         ?>
                         </table>
                         </center>

                </section>
		<!-- FOOTER -->
		
	</div><!-- //PAGE -->
</div>

	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.sticky.js" type="text/javascript"></script>
	<script src="js/parallax.js" type="text/javascript"></script>
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/jquery.jcarousel.js" type="text/javascript"></script>
	<script src="js/jqueryui.custom.min.html" type="text/javascript"></script>
	<script src="js/fancySelect.js"></script>
	<script src="js/animate.js" type="text/javascript"></script>
	<script src="js/myscript.js" type="text/javascript"></script>
	
</body>
<script src="js/jqueryori.min.js"></script>
    <script>
        $('body').on('change', '#gl_item_category', function () {
            $additem = $('#gl_item_category').val();
            $.ajax({type:'post',url:''});
            $.ajax({
            type:'post',
                    url:'get_state.php',
                    data:{additem:$additem},
                    success:function(response)
                    {
                    //console.log(response);
                    $ar = response.split(",");
                            $str = "";
                            for (var i = 0; i < $ar.length; i++)
                    {
                    $str += '<option>' + $ar[i] + "</option>";
                    }
                    $('#gl_item_sub_category').html($str);
                }
                    });
        });


    </script>

<!-- Mirrored from demo.evatheme.com/html/glammy/women.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Aug 2017 08:04:41 GMT -->
</html>