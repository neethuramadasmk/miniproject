<!DOCTYPE html>
<html lang="en">
<?php
    include './conn1.php'; 
    session_start();
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
    $login_id=$_SESSION['id'];
    $sql1= mysqli_query($con, "SELECT * FROM `user` WHERE `log_id`=$login_id and status=1");
    $row1 = mysqli_fetch_array($sql1);
    $name=$row1['fname'];
?>
<head>
	
	<meta charset="utf-8">
	<title>Glammy | Furniture Store </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/favicon.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/fancySelect.css" rel="stylesheet" media="screen, projection" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="../../../netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	
</head>
<style>
    div.img {
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    width: 180px;
	background-color:lightgoldenrodyellow;
	height:290px;
	border-radius:13px 13px 13px 13px;
}
div.img:hover span:after {
  position: relative;
  opacity: 0;
  top: 0;
  left:980px;
  transition: 0.5s;
}



div.img:hover span{
    border: 1px solid #777;
	padding-right: 0px;
}

div.img:hover span:after{
  opacity: 1;
  right: 0;
}

div.img img {
    height:200px;
	width:190px;
}

div.desc {
    padding: 15px;
    text-align: center;
	font-family:Benguiat Bk BT;
}
.button1 {	width:100px;
	background-color:#33FF99;
	border-radius:13px;
	cursor: pointer;
}

</style>
<body>

<!-- PRELOADER -->
<div id="preloader"><img src="images/preloader.gif" alt="" /></div>
<!-- //PRELOADER -->
<div class="preloader_hide">

	<!-- PAGE -->
	<div id="page">
	
		<!-- HEADER -->
		<header>
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo">
                                            <a href="userhome.php" ><img src="images/logo.png" alt="" /></a>
					</div><!-- //LOGO -->
					
					
					
					<!-- MENU -->
					<ul class="navmenu center">
                                            <li class="sub-menu active"><a href="userhome.php" >Home</a>
						<li class="sub-menu first"><a href="changepassword.php" >Change Password</a>
							<!-- MEGA MENU -->
							
						</li>
						<li class="sub-menu"><a href="wallet.php" >Wallet</a>
							
						</li>
                                                <li class="sub-menu"><a href="cart.php" >Cart</a>
						</li>
                                                <li><a href="viewtransactions.php" >Transactions</a></li>
                                                	
						
						<li class="sub-menu"><a href="javascript:void(0);" >Used Items</a>
							<!-- MEGA MENU -->
							<ul class="mega_menu megamenu_col1 clearfix">
								<li class="col">
									<ol>
										<li><a href="uitembuy.php" >Buy</a></li>
										<li><a href="uitemsell.php" >Sell</a></li>
									</ol>
								</li>
							</ul><!-- //MEGA MENU -->
						</li>
                                                <li><a href="notifications.php" >Notifications</a></li>
						<li class="last sale_menu"><a href="logout.php" >logout</a></li>
					</ul><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
		
		<!-- BREADCRUMBS -->
		<section class="breadcrumb women parallax margbot30">
			
			<!-- CONTAINER -->
			<div class="container">
                            <h2><?php echo $name; ?></h2>
			</div><!-- //CONTAINER -->
		</section><!-- //BREADCRUMBS -->
		
		
		<!-- SHOP BLOCK -->
		<section class="shop">
			
			<!-- CONTAINER -->
			<div class="container">
			
				<!-- ROW -->
				<div class="row">
					
					<!-- SIDEBAR -->
					<div id="sidebar" class="col-lg-3 col-md-3 col-sm-3 padbot50">
						
						<!-- CATEGORIES -->
                                                 <?php
                                                        $result =mysqli_query($con,"SELECT `category_id`, `c_name`, `img`, `status` FROM `category` where status=1 order by c_name;");
                                                        while (($t=mysqli_fetch_array($result))){
                                                            $cat_id=$t['category_id'];
                                                   ?>
						<div class="sidepanel widget_categories">
							<h3><?php  echo ucfirst($t['c_name']);  ?></h3>
							<ul>
                                                            <?php
                                                                 $result1 =mysqli_query($con,"SELECT * FROM `subcategory` where status=1 and category_id=$cat_id order by sub_cname;");
                                                                 while (($t1=mysqli_fetch_array($result1))){
                                                            ?>
                                                            <li><a href="category.php?sb_id=<?php  echo ucfirst($t1['subcategory_id']);  ?>" ><?php  echo ucfirst($t1['sub_cname']);  ?></a></li>
                                                            <?php
                                                                 }
                                                            ?>
                                                                
								
							</ul>
						</div><!-- //CATEGORIES -->
						<?php
                                                    }
                                               ?>
							
						
					</div><!-- //SIDEBAR -->
					
					
					<!-- SHOP PRODUCTS -->
					<div class="col-lg-9 col-sm-9 col-sm-9 padbot20">
						
						<!-- SHOP BANNER -->
						<div class="banner_block margbot15">
							<a class="banner nobord" href="javascript:void(0);" ><img src="images/tovar/banner21.html" alt="" /></a>
						</div><!-- //SHOP BANNER -->
						
						<!-- SORTING TOVAR PANEL -->
						<div class="sorting_options clearfix">
							<?php
                                                            $result4=mysqli_query($con,"SELECT COUNT(*)as count FROM items where status=1;");
                                                                $t3=mysqli_fetch_array($result4);
                                                        
                                                        ?>
							<!-- COUNT TOVAR ITEMS -->
							<div class="count_tovar_items">
								<p>Items</p>
								<span><?php echo $t3['count']; ?> Items</span>
							</div><!-- //COUNT TOVAR ITEMS -->
							
							<!-- TOVAR FILTER -->
							<div class="product_sort">
								<p>SORT BY</p>
                                                                <form action="" method="POST">
                                                                    <select class="basic" name="sort_sel" required>
                                                                            <option value="">Choose</option>
                                                                            <option value="p">Popularity</option>
                                                                            <option value="d">Date</option>
                                                                    </select>
                                                                    <input type="submit" name="submit" value="SORT"/>
                                                                </form>    
							</div><!-- //TOVAR FILTER -->
							
						</div><!-- //SORTING TOVAR PANEL -->
						
						
						<!-- ROW -->
						<div class="row shop_block">
                                                    <!-- TOVAR1 -->
							<div class="tovar_wrapper col-lg-4 col-md-4 col-sm-6 col-xs-6 col-ss-12 padbot40">
                                                        <center>
                                                        <table>
                                                        <?php 
                                                            if(isset($_POST['submit']))
                                                            {
                                                                $sbc=$_POST['sort_sel'];
                                                                if($sbc=='p'){
                                                                    $qry3="select * from items WHERE status=1 order by date";
                                                                }
                                                                elseif($sbc=='d'){
                                                                    $qry3="select * from items WHERE status=1 order by date desc";
                                                                }
                                                                    $res3=mysqli_query($con,$qry3);
                                                                $i=0;
                                                                while($ar3=mysqli_fetch_array($res3))
                                                                {
                                                                    $i++;
                                                                    if($i % 6==1)
                                                                    {
                                                                            echo "<tr>";
                                                                    }
                                                            ?>
                                                                    <td>
                                                                                    <!-- <form action="book.php" method="post"> -->
                                                                        <div class="img">
                                                                            <center>
                                                                            <span><img src="<?php echo $ar3['img']?>" alt="Trolltunga Norway"></span>
                                                                            <h4>
                                                                                <?php echo $ar3['item_name'];?>
                                                                            </h4>
                                                                            Price: <?php echo $ar3['price'];?><br>
                                                                                <a href="itempage.php?pid=<?php echo $ar3['item_id']; ?>" ><button type="submit" value="More Details1" name="submit" class="button1"/>More Details</button>
                                                                               </a>
                                                                            </center> 
                                                                        </div>
                                                                       <!-- </form> -->
                                                                    </td>
                                                            <?php } 
                                                             }
                                                             else
                                                            {

                                                            $query3="select * from items where status=1";
                                                            $result3=mysqli_query($con,$query3);
                                                            $i=0;
                                                            while($array3=mysqli_fetch_array($result3))
                                                            {
                                                                    $i++;
                                                                    if($i % 6==1)
                                                                    {
                                                                            echo "<tr>";
                                                                    }
                                                            ?>
                                                                    <td>
                                                                                    <!-- <form action="petdetails.php" method="post"> -->
                                                                            <div class="img">
                                                                            <center>
                                                                            <span><img src="<?php echo $array3['img']?>" alt="Trolltunga Norway"></span>
                                                                            <h4>
                                                                                <?php echo $array3['item_name'];?>
                                                                            </h4>
                                                                            Price: <?php echo $array3['price'];?><br>
                                                                                <a href="itempage.php?pid=<?php echo $array3['item_id']; ?>" ><button type="submit" value="More Details1" name="submit" class="button1"/>More Details</button>
                                                                               </a>
                                                                            </center> 
                                                                        </div>
                                                                     <!--  </form> -->
                                                                            </td>
                                                             <?php } 
                                                             }
                                                             ?>
                                                        </table>
                                                        </center>
							</div><!-- //TOVAR1 -->
                                                        <?php
                                                           // }
                                                        ?>
						</div><!-- //ROW -->
						
						<hr>
						
						<div class="clearfix">
							<!-- PAGINATION -->
							<ul class="pagination">
								<li><a href="javascript:void(0);" >1</a></li>
								<li><a href="javascript:void(0);" >2</a></li>
								<li class="active"><a href="javascript:void(0);" >3</a></li>
								<li><a href="javascript:void(0);" >4</a></li>
								<li><a href="javascript:void(0);" >5</a></li>
								<li><a href="javascript:void(0);" >6</a></li>
								<li><a href="javascript:void(0);" >...</a></li>
							</ul><!-- //PAGINATION -->
							
							<a class="show_all_tovar" href="javascript:void(0);" >show all</a>
							
						</div>
						
						<hr>
						
						
					</div><!-- //SHOP PRODUCTS -->
				</div><!-- //ROW -->
			</div><!-- //CONTAINER -->
		</section><!-- //SHOP -->
		
	
		
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.sticky.js" type="text/javascript"></script>
	<script src="js/parallax.js" type="text/javascript"></script>
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/jquery.jcarousel.js" type="text/javascript"></script>
	<script src="js/jqueryui.custom.min.html" type="text/javascript"></script>
	<script src="js/fancySelect.js"></script>
	<script src="js/animate.js" type="text/javascript"></script>
	<script src="js/myscript.js" type="text/javascript"></script>
	
</body>

<!-- Mirrored from demo.evatheme.com/html/glammy/women.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Aug 2017 08:04:41 GMT -->
</html>