<!DOCTYPE html>
<html lang="en">
<?php
    include './conn1.php'; 
    session_start();
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
?>
<head>
	
	<meta charset="utf-8">
	<title>Glammy | Furniture Store </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/favicon.ico">
        <meta charset="utf-8">
        <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
        <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Satisfy|Bree+Serif|Candal|PT+Sans">
        <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/fancySelect.css" rel="stylesheet" media="screen, projection" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
        <link href="css/mystyle.css" rel="stylesheet" type="text/css" />
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="../../../netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	
</head>
<body>
       
<!-- PRELOADER -->
<div id="preloader"><img src="images/preloader.gif" alt="" /></div>
<!-- //PRELOADER -->
<div class="preloader_hide">

	<!-- PAGE -->
	<div id="page">
	
		<!-- HEADER -->
		<header>
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo">
                                            <a href="adminpage.php" ><img src="images/logo.png" alt="" /></a>
					</div><!-- //LOGO -->
					
					
					
					<!-- MENU -->
					<ul class="navmenu center">
                                            <li class="sub-menu active"><a href="adminpage.php" >Home</a></li>
						<li class="sub-menu first"><a href="javascript:void(0);" >ADD</a>
							<!-- MEGA MENU -->
							<ul class="mega_menu megamenu_col1 clearfix">
								<li class="col">
									<ol>
                                                                            <li><a href="addcategory.php" >Category</a></li>
										<li><a href="addsubcat.php" >Sub Category</a></li>
										<li><a href="addfurniture.php" >Furniture</a></li>
                                                                                <li><a href="addwoodtype.php" >Wood Type</a></li>
									</ol>
								</li>
							</ul><!-- //MEGA MENU -->
						</li>
						<li class="sub-menu first"><a href="javascript:void(0);" >VIew</a>
							<!-- MEGA MENU -->
							<ul class="mega_menu megamenu_col1 clearfix">
								<li class="col">
									<ol>
                                                                            <li><a href="viewuseditems.php" >Used Item</a></li>
                                                                            <li><a href="viewdeleteditems.php" >Deleted Items</a></li>
                                                                            <li><a href="viewaddeditems.php" >Added Items</a></li>
									
                                                                        </ol>
								</li>
							</ul><!-- //MEGA MENU -->
						</li>
						<li class="sub-menu first"><a href="javascript:void(0);" >Items</a>
							<!-- MEGA MENU -->
							<ul class="mega_menu megamenu_col1 clearfix">
								<li class="col">
									<ol>
                                                                            <li><a href="viewitems.php" >View Item</a></li>
                                                                            <li><a href="viewlessitems.php" >Shortage Items</a></li>
                                                                        </ol>
								</li>
							</ul><!-- //MEGA MENU -->
						</li>
						<li class="sub-menu active"><a href="transactions.php" >Transactions</a></li>
						<li class="last sale_menu"><a href="logout.php" >logout</a></li>
					</ul><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
		
		<!-- BREADCRUMBS -->
		<section class="breadcrumb women parallax margbot30">
			
			<!-- CONTAINER -->
			<div class="container">
				<h2>Admin</h2>
			</div><!-- //CONTAINER -->
		</section><!-- //BREADCRUMBS -->
		
		
		<!-- SHOP BLOCK -->
		<section class="shop">
			
			<!-- CONTAINER -->
			<div class="container">
			
				<!-- ROW -->
				<div class="row">
				<div class="container">
                                    <div class="inner text-center">
                                        <form action="#" name="myform" method="POST" class="form-inline">
                                            <div class="span12" style="border-radius: 5px; border-style: solid; border-width: 1px; margin-left: 20px;" >
                                                <h1 style="margin-left: 10px; "> <b> View Transactions</b></h1>
                                                <center>
                                                <table>
                                                    <tr>
                                                        <td>
                                                            <label>Select By Date</label>
                                                            <input type="date" name="mydate1" id="mydate1" class="input-medium" required="" />&nbsp;
                                                        </td>
                                                        <td>
                                                            <label>Select By Date</label>
                                                            <input type="date" name="mydate2" id="mydate2" class="input-medium" />&nbsp;
                                                        </td>
                                                        <td>
                                                            <input type="submit" class="btn-primary  " name="myday" value="Search" id='myday' />
                                                        </td>

                                                </tr>
                                                </table>
                                                </center>
                                            </div>
                                        </form>
                                        <table border="2" width="300" cellspacing="2" cellpadding="1" class="table table-striped" style=" border-radius: 5px; border-style: solid; border-width: 1px; ">
                                        <head>
                                            <tr>
                                                <th>Transaction ID</th>
                                                <th>User Name</th>
                                                <th>Item Name</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Total Amount</th>
                                                <th>Date Of Transaction</th>
                                            </tr>
                                            </head>
                                            <tbody>
                                                <?php
                                                    if(isset($_POST['submit']))
                                                    {
                                                    }
                                                if(isset($_POST['myday']))
                                                    {
                                                        $mydate1=$_POST["mydate1"];
                                                        $mydate2=$_POST["mydate2"];
                                                        if($mydate1==$mydate2){
                                                            $aa="select `pay_id`, `log_id`, `item_id`,`qty`,DATE(date) as date,amount, `status` from payment where date like '$mydate1%' ";
                                                        }
                                                        else{
                                                        $aa="select  `pay_id`, `log_id`, `item_id`,`qty`,DATE(date) as date,amount, `status` from payment where date between '$mydate1' and '$mydate2' ";
                                                        }
                                                        //echo $aa;
                                                        $result=mysqli_query($con,$aa);
                                                        while($row=mysqli_fetch_array($result))
                                                        {
                                                           
                                                            $unm=$row['log_id'];
                                                            $it=$row['item_id'];
                                                                $un=mysqli_query($con,"select * from user where log_id=$unm");
                                                                    while($row2=mysqli_fetch_array($un)){
                                                                        $itm=mysqli_query($con,"select * from items where item_id=$it");
                                                                            while($row3=mysqli_fetch_array($itm)){

                                                 ?>
                                  <form name="form" action="#" method="POST" id="form">


                                <tr>
                                <td><?php echo $row['pay_id'];?></td>
                                <td><?php echo $row2['fname'];?></td>
                                <td><?php echo ucfirst($row3['item_name']);?></td>
                                <td><?php echo $row3['price'];?></td>
                                <td><?php echo $row['qty'];?></td>
                                <td><?php echo $row['amount'];?></td>
                                <td><?php echo $row['date'];?></td>

                                </tr>

                                <?php
                                                                            
                                                            }
                                                            }
                                }
                              }
                                ?>
                                </table>

                             </div>
                                </div>	
				
					
					
				</div><!-- //ROW -->
			</div><!-- //CONTAINER -->
		</section><!-- //SHOP -->
		
	
	</div><!-- //PAGE -->
</div>

<!-- TOVAR MODAL CONTENT -->
<div id="modal-body" class="clearfix">
	<div id="tovar_content"></div>
	<div class="close_block"></div>
</div><!-- TOVAR MODAL CONTENT -->

	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.sticky.js" type="text/javascript"></script>
	<script src="js/parallax.js" type="text/javascript"></script>
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/jquery.jcarousel.js" type="text/javascript"></script>
	<script src="js/jqueryui.custom.min.html" type="text/javascript"></script>
	<script src="js/fancySelect.js"></script>
	<script src="js/animate.js" type="text/javascript"></script>
	<script src="js/myscript.js" type="text/javascript"></script>
	
</body>

<!-- Mirrored from demo.evatheme.com/html/glammy/women.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Aug 2017 08:04:41 GMT -->
</html>