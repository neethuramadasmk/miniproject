<?php
    $con=mysqli_connect("localhost","root","","furniturestore");
    mysqli_select_db($con,"furniturestore");
?>

