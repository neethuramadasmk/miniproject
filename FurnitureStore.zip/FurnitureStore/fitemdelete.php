<?php
    session_start();  
    include './conn1.php';
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
    $id=$_REQUEST['id'];
    $sql="update items set status=0 where item_id='$id'";
//    echo $sql;
    $results=mysqli_query($con,$sql);
    if($results>0)
        {
?>
            <script>
                    window.location="viewitems.php";
                    alert("Deleted");
            </script>

<?php
        }
        else{
            echo "Can not delete";
            header("location:viewitems.php");
        }
?>

