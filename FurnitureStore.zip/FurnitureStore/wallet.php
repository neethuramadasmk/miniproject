<!DOCTYPE html>
<html lang="en">
<?php
    include './conn1.php'; 
    session_start();
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
    $login_id=$_SESSION['id'];
    $sql1= mysqli_query($con, "SELECT * FROM `user` WHERE `log_id`=$login_id and status=1");
    $row1 = mysqli_fetch_array($sql1);
    $name=$row1['fname'];
?>
<head>
	
	<meta charset="utf-8">
	<title>Glammy | Furniture Store </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/favicon.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/fancySelect.css" rel="stylesheet" media="screen, projection" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
        
        <link href="css/mystyle.css" rel="stylesheet" type="text/css" />
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="../../../netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	
</head>
<script>
            function gCno(){
                var gl_cardno=document.gl_wallet_form.gl_cardno.value;
                if(isNaN(gl_cardno)){
                    document.gl_wallet_form.gl_cardno.style.border = "1px solid red";
                    alert("Card Number Only Contain Digits");
                    document.gl_wallet_form.gl_cardno.focus();
                    return false;
                }
                if(gl_cardno.length !== 16){
                    document.gl_wallet_form.gl_cardno.style.border = "1px solid red";
                    alert("Card Number must be 16 Digits");
                    document.gl_wallet_form.gl_cardno.focus();
                    return false;
                }
            }
            function gCvv(){
                var gl_cvv=document.gl_wallet_form.gl_cvv.value;
                if(isNaN(gl_cvv)){
                    document.gl_wallet_form.gl_cvv.style.border = "1px solid red";
                    alert("CVV Only Contain Digits");
                    document.gl_wallet_form.gl_cvv.focus();
                    return false;
                }
                if(gl_cvv.length !== 3){
                    document.gl_wallet_form.gl_cvv.style.border = "1px solid red";
                    alert("CVV must be 3 Digits");
                    document.gl_wallet_form.gl_cvv.focus();
                    return false;
                }
            }
            function aAmount(){
                var gl_amt=document.gl_wallet_form.gl_amt.value;
                if(isNaN(gl_amt)){
                    document.gl_wallet_form.gl_amt.style.border = "1px solid red";
                    alert("Only Digits");
                    document.gl_wallet_form.gl_amt.focus();
                    return false;
                }
            }
            
            
            function addWallet(){
                var gl_cardno=document.gl_wallet_form.gl_cardno.value;
                if(isNaN(gl_cardno)){
                    document.gl_wallet_form.gl_cardno.style.border = "1px solid red";
                    alert("Card Number Only Contain Digits");
                    document.gl_wallet_form.gl_cardno.focus();
                    return false;
                }
                if(gl_cardno.length !== 16){
                    document.gl_wallet_form.gl_cardno.style.border = "1px solid red";
                    alert("Card Number must be 16 Digits");
                    document.gl_wallet_form.gl_cardno.focus();
                    return false;
                }
                
                var gl_cvv=document.gl_wallet_form.gl_cvv.value;
                if(isNaN(gl_cvv)){
                    document.gl_wallet_form.gl_cvv.style.border = "1px solid red";
                    alert("CVV Only Contain Digits");
                    document.gl_wallet_form.gl_cvv.focus();
                    return false;
                }
                if(gl_cvv.length !== 3){
                    document.gl_wallet_form.gl_cvv.style.border = "1px solid red";
                    alert("CVV must be 3 Digits");
                    document.gl_wallet_form.gl_cvv.focus();
                    return false;
                }
                var gl_amt=document.gl_wallet_form.gl_amt.value;
                if(isNaN(gl_amt)){
                    document.gl_wallet_form.gl_amt.style.border = "1px solid red";
                    alert("Amount Only Digits");
                    document.gl_wallet_form.gl_amt.focus();
                    return false;
                }
            }
            </script>
<body>
<?php
        if(isset($_POST["gl_wallet_addbtn"])){
            $gl_cardno= htmlspecialchars($_POST['gl_cardno']);
            $gl_bank_name=htmlspecialchars($_POST['gl_bank_name']); 
            $gl_cvv=htmlspecialchars($_POST['gl_cvv']); 
            $gl_amt=htmlspecialchars($_POST['gl_amt']); 
            $uname=$_SESSION['uname'];
            $sql2="SELECT `w_id`, `log_id`, `bank_name`, `balance`, `status` FROM `wallet` WHERE log_id=$login_id";
            $result=mysqli_query($con,$sql2);
            $t=mysqli_fetch_array($result);
            $blce_amt=$t['balance'];
            if($t['status']==1 ) {
                $amt=$gl_amt+$t['balance'];
                $sql3="UPDATE `wallet` SET `balance`=$amt WHERE log_id=$login_id";
                $result3=mysqli_query($con,$sql3);
                echo "<script> alert('Money Added'); </script>";
            }
            else{
            
                $sql1="INSERT INTO `wallet`(`log_id`, `bank_name`, `balance`, `status`) VALUES ($login_id,'$gl_bank_name',$gl_amt,1);";
                if (mysqli_query($con,$sql1) > 0){
                    echo "<script> alert('Added'); </script>";
                }
                else{
                    echo "<script> alert ('Unsuccessfull !'); </script>";
                }
            }
    }
    ?>
<!-- PRELOADER -->
<div id="preloader"><img src="images/preloader.gif" alt="" /></div>
<!-- //PRELOADER -->
<div class="preloader_hide">

	<!-- PAGE -->
	<div id="page">
	
		<!-- HEADER -->
		<header>
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo">
                                            <a href="userhome.php" ><img src="images/logo.png" alt="" /></a>
					</div><!-- //LOGO -->
					
					
					
					<!-- MENU -->
					<ul class="navmenu center">
                                            <li class="sub-menu active"><a href="userhome.php" >Home</a>
						<li class="sub-menu first"><a href="changepassword.php" >Change Password</a>
							<!-- MEGA MENU -->
							
						</li>
						<li class="sub-menu"><a href="wallet.php" >Wallet</a>
							
						</li>
                                                <li class="sub-menu"><a href="cart.php" >Cart</a>
						</li>
                                                <li><a href="viewtransactions.php" >Transactions</a></li>
                                                	
						
						<li class="sub-menu"><a href="javascript:void(0);" >Used Items</a>
							<!-- MEGA MENU -->
							<ul class="mega_menu megamenu_col1 clearfix">
								<li class="col">
									<ol>
										<li><a href="uitembuy.php" >Buy</a></li>
										<li><a href="uitemsell.php" >Sell</a></li>
									</ol>
								</li>
							</ul><!-- //MEGA MENU -->
						</li>
                                                <li><a href="notifications.php" >Notifications</a></li>
						<li class="last sale_menu"><a href="logout.php" >logout</a></li>
					</ul><!-- //MENU --><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
		
		<!-- BREADCRUMBS -->
		<section class="breadcrumb women parallax margbot30">
			
			<!-- CONTAINER -->
			<div class="container">
                            <h2><?php echo $name; ?></h2>
			</div><!-- //CONTAINER -->
		</section><!-- //BREADCRUMBS -->
		
		
		<!-- SHOP BLOCK -->
		<section class="shop">
			
			<!-- CONTAINER -->
			<div class="container">
			
				<!-- ROW -->
				<div class="row">
					
					<!-- SIDEBAR -->
					<div id="sidebar" class="col-lg-3 col-md-3 col-sm-3 padbot50">
						
						<!-- CATEGORIES -->
                                                 <?php
                                                        $result =mysqli_query($con,"SELECT `category_id`, `c_name`, `img`, `status` FROM `category` where status=1 order by c_name;");
                                                        while (($t=mysqli_fetch_array($result))){
                                                            $cat_id=$t['category_id'];
                                                   ?>
						<div class="sidepanel widget_categories">
							<h3><?php  echo ucfirst($t['c_name']);  ?></h3>
							<ul>
                                                            <?php
                                                                 $result1 =mysqli_query($con,"SELECT * FROM `subcategory` where status=1 and category_id=$cat_id order by sub_cname;");
                                                                 while (($t1=mysqli_fetch_array($result1))){
                                                            ?>
                                                            <li><a href="category.php?sb_id=<?php  echo ucfirst($t1['subcategory_id']);  ?>" ><?php  echo ucfirst($t1['sub_cname']);  ?></a></li>
                                                            <?php
                                                                 }
                                                            ?>
                                                                
								
							</ul>
						</div><!-- //CATEGORIES -->
						<?php
                                                    }
                                               ?>
							
						
					</div><!-- //SIDEBAR -->
                                       
					
				</div><!-- //ROW -->
                                 <div class="gl_wallet_container">
                                    <form class="gl_wallet_form" name="gl_wallet_form" id="gl_wallet_form" action="wallet.php" method="POST"  onsubmit="return addWallet()" enctype="multipart/form-data">
                    <div class="gl_wallet_form_container" align="center">
                        <h2 align="center" style="color: black;">Add Money</h2>
                        <input type="text" placeholder="Enter Card Number" name="gl_cardno"  id="gl_cardno" required onChange="return gCno()">
                        <br/>
                        
                        <select name="gl_bank_name" id="gl_bank_name" required >
                            //<?php
//                                $sql="Select bank_id, bank_name from bank Order By bank_name;";
//                                $rset=mysqli_query($con,$sql);
//                                $records=mysqli_fetch_array($sql);
//                                echo "<option value=''>Choose a Bank</option>";
//                                foreach($rset as $records){
//                                    
//                                    echo "<option value='{$records["category_id"]}'>{$records["c_name"]}  </option>";
//                                    
//                                }
//                             ?>
                            <option value="">Choose a bank</option>
                            <option value="SBI">SBI</option>
                            <option value="Federal Bank">Federal Bank</option>
                            <option value="South Indian Bank">South Indian Bank</option>
                           
                        </select>
                        <br/>
                        
                        <input type="text" placeholder="CVV" name="gl_cvv"  id="gl_cvv" required onChange="return gCvv()">
                        <br/>
                        
                        <input type="text" placeholder="Amount" name="gl_amt"  id="gl_amt" required onChange="return aAmount()">
                        <br/>
                        <input type="submit" style="margin-right: 120px;" class="gl_wallet_addbtn" id="gl_wallet_addbtn" name="gl_wallet_addbtn" value="ADD"/>
                        
                    </div>
                </form>
    </div>
    		</div><!-- //CONTAINER -->
                <div class="gl_wallet_balance_container">
        <?php
            $sql5="SELECT * FROM `wallet` WHERE log_id=$login_id";
            $result5=mysqli_query($con,$sql5);
            $t5=mysqli_fetch_array($result5);
            $blce_amt=$t5['balance'];
            echo "Balance= $blce_amt";
        ?>
    </div> 
	
		</section><!-- //SHOP -->
		
	
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.sticky.js" type="text/javascript"></script>
	<script src="js/parallax.js" type="text/javascript"></script>
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/jquery.jcarousel.js" type="text/javascript"></script>
	<script src="js/jqueryui.custom.min.html" type="text/javascript"></script>
	<script src="js/fancySelect.js"></script>
	<script src="js/animate.js" type="text/javascript"></script>
	<script src="js/myscript.js" type="text/javascript"></script>
	
</body>

<!-- Mirrored from demo.evatheme.com/html/glammy/women.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Aug 2017 08:04:41 GMT -->
</html>