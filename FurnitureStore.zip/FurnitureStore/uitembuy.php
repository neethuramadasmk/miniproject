<!DOCTYPE html>
<html lang="en">
<?php
    include './conn1.php';
    session_start();
?>
<head>
	
	<meta charset="utf-8">
	<title>Glammy | Furniture Store </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/favicon.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/fancySelect.css" rel="stylesheet" media="screen, projection" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="../../../netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	
</head>
<style>
    div.img {
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    width: 180px;
	background-color:lightgoldenrodyellow;
	height:290px;
	border-radius:13px 13px 13px 13px;
}
div.img:hover span:after {
  position: relative;
  opacity: 0;
  top: 0;
  left:980px;
  transition: 0.5s;
}



div.img:hover span{
    border: 1px solid #777;
	padding-right: 0px;
}

div.img:hover span:after{
  opacity: 1;
  right: 0;
}

div.img img {
    height:200px;
	width:190px;
}

div.desc {
    padding: 15px;
    text-align: center;
	font-family:Benguiat Bk BT;
}
.button1 {	width:100px;
	background-color:#33FF99;
	border-radius:13px;
	cursor: pointer;
}

</style>
<body>

<!-- PRELOADER -->
<div id="preloader"><img src="images/preloader.gif" alt="" /></div>
<!-- //PRELOADER -->
<div class="preloader_hide">

	<!-- PAGE -->
	<div id="page">
	
		<!-- HEADER -->
		<header>
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
                            <?php
                            if(isset($_SESSION['id'])){                            
                            ?>
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo">
                                            <a href="userhome.php" ><img src="images/logo.png" alt="" /></a>
					</div><!-- //LOGO -->
					
                                        <!-- MENU -->
					<!-- MENU -->
					<ul class="navmenu center">
                                            <li class="sub-menu active"><a href="userhome.php" >Home</a>
						<li class="sub-menu first"><a href="changepassword.php" >Change Password</a>
							<!-- MEGA MENU -->
							
						</li>
						<li class="sub-menu"><a href="wallet.php" >Wallet</a>
							
						</li>
                                                <li class="sub-menu"><a href="cart.php" >Cart</a>
						</li>
                                                <li><a href="viewtransactions.php" >Transactions</a></li>
                                                	
						
						<li class="sub-menu"><a href="javascript:void(0);" >Used Items</a>
							<!-- MEGA MENU -->
							<ul class="mega_menu megamenu_col1 clearfix">
								<li class="col">
									<ol>
										<li><a href="uitembuy.php" >Buy</a></li>
										<li><a href="uitemsell.php" >Sell</a></li>
									</ol>
								</li>
							</ul><!-- //MEGA MENU -->
						</li>
                                                <li><a href="notifications.php" >Notifications</a></li>
						<li class="last sale_menu"><a href="logout.php" >logout</a></li>
					</ul><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
                                <?php
                            }else{
                            ?>
                               <div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo">
                                            <a href="index.php" ><img src="images/logo.png" alt="" /></a>
					</div><!-- //LOGO -->
					
                                        <!-- MENU -->
					<ul class="navmenu center">
                                            <li class="sub-menu active"><a href="index.php" >Home</a>
							
                                            </li>
                                            
                                            <li class="sub-menu"><a href="javascript:void(0);" >Used Items</a>
							<!-- MEGA MENU -->
							<ul class="mega_menu megamenu_col1 clearfix">
								<li class="col">
									<ol>
										<li><a href="uitembuy.php" >Buy</a></li>
										<li><a href="uitemsell.php" >Sell</a></li>
									</ol>
								</li>
							</ul><!-- //MEGA MENU -->
						</li>
                                            <li class="last sale_menu"><a href="login.php" >Login</a></li>
					</ul><!-- //MENU -->
				</div><!-- //MENU BLOCK --> 
                               <?php
                            }
                            ?>  
                                
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
		
		<!-- BREADCRUMBS -->
		<section class="breadcrumb women parallax margbot30">
			
			<!-- CONTAINER -->
			<div class="container">
                            <h2>WELCOME</h2>
			</div><!-- //CONTAINER -->
		</section><!-- //BREADCRUMBS -->
		
		
		<!-- SHOP BLOCK -->
		<section class="shop">
			
			<!-- CONTAINER -->
			<div class="container">
			
				<!-- ROW -->
				<div class="row">
					
					<!-- SHOP PRODUCTS -->
					<div class="col-lg-9 col-sm-9 col-sm-9 padbot20">
						
						<!-- SHOP BANNER -->
						<div class="banner_block margbot15">
							<a class="banner nobord" href="javascript:void(0);" ><img src="images/tovar/banner21.html" alt="" /></a>
						</div><!-- //SHOP BANNER -->
						
						<!-- SORTING TOVAR PANEL -->
						<div class="sorting_options clearfix">
							<?php
                                                            $sql3=mysqli_query($con,"SELECT COUNT(*)as count FROM used_item where status=1");
                                                                $row3=mysqli_fetch_array($sql3);
                                                        
                                                        ?>
							<!-- COUNT TOVAR ITEMS -->
							<div class="count_tovar_items">
								<p>Items</p>
								<span><?php echo $row3['count']; ?>Used Items</span>
							</div><!-- //COUNT TOVAR ITEMS -->
							
							<!-- TOVAR FILTER -->
							<div class="product_sort">
								<p>SORT BY</p>
                                                                <form action="" method="POST">
                                                                    <select class="basic" name="sort_sel" required>
                                                                            <option value="">Choose</option>
                                                                            <?php
                                                                                    $sql10="Select * from subcategory Order By sub_cname;";
                                                                                    $rset10=mysqli_query($con,$sql10);
                                                                                    $records10=mysqli_fetch_array($sql10);
                                                                                    echo "<option value=''>Select a Category</option>";
                                                                                    foreach($rset10 as $records10){

                                                                                        echo "<option value='{$records10["subcategory_id"]}'>{$records10["sub_cname"]}  </option>";

                                                                                    }
                                                                                ?>
                                                                    </select>
                                                                    <input type="submit" name="submit" value="SORT"/>
                                                                </form>    
							</div><!-- //TOVAR FILTER -->
							
						</div><!-- //SORTING TOVAR PANEL -->
						
						
						<!-- ROW -->
						<div class="row shop_block">
                                                    <!-- TOVAR1 -->
							<div class="tovar_wrapper col-lg-4 col-md-4 col-sm-6 col-xs-6 col-ss-12 padbot40">
                                                        <center>
                                                        <table>
                                                        <?php 
                                                            if(isset($_POST['submit']))
                                                            {
                                                                $sbc=$_POST['sort_sel'];
                                                               // echo "<script>alert($sbc);</script>";
                                                                    $row4=mysqli_query($con,"select * from used_item WHERE status=2 and subcategory_id=$sbc order by date desc");
                                                                $i=0;
                                                                while($res4=mysqli_fetch_array($row4))
                                                                {
                                                                    $i++;
                                                                    if($i % 6==1)
                                                                    {
                                                                            echo "<tr>";
                                                                    }
                                                            ?>
                                                                    <td>
                                                                                    <!-- <form action="book.php" method="post"> -->
                                                                        <div class="img">
                                                                            <center>
                                                                            <span><img src="<?php echo $res4['img']?>" alt="Trolltunga Norway"></span>
                                                                            <h4>
                                                                                <?php echo $res4['used_item_name'];?>
                                                                            </h4>
                                                                            Price: <?php echo $res4['price'];?><br>
                                                                                <a href="useditempage.php?pid=<?php echo $res4['used_item_id']; ?>" ><button type="submit" value="More Details1" name="submit" class="button1"/>More Details</button>
                                                                               </a>
                                                                            </center> 
                                                                        </div>
                                                                       <!-- </form> -->
                                                                    </td>
                                                            <?php } 
                                                             }
                                                             else
                                                            {

                                                            $sql5="select * from used_item where status=2";
                                                            $row5=mysqli_query($con,$sql5);
                                                            $i=0;
                                                            while($res5=mysqli_fetch_array($row5))
                                                            {
                                                                    $i++;
                                                                    if($i % 6==1)
                                                                    {
                                                                            echo "<tr>";
                                                                    }
                                                            ?>
                                                                    <td>
                                                                                    <!-- <form action="petdetails.php" method="post"> -->
                                                                            <div class="img">
                                                                            <center>
                                                                            <span><img src="<?php echo $res5['img']?>" alt="Trolltunga Norway"></span>
                                                                            <h4>
                                                                                <?php echo $res5['used_item_name'];?>
                                                                            </h4>
                                                                            Price: <?php echo $res5['price'];?><br>
                                                                                <a href="useditempage.php?pid=<?php echo $res5['used_item_id']; ?>" ><button type="submit" value="More Details1" name="submit" class="button1"/>More Details</button>
                                                                               </a>
                                                                            </center> 
                                                                        </div>
                                                                     <!--  </form> -->
                                                                            </td>
                                                             <?php } 
                                                             }
                                                             ?>
                                                        </table>
                                                        </center>
							</div><!-- //TOVAR1 -->
                                                        <?php
                                                           // }
                                                        ?>
						</div><!-- //ROW -->
						
						<hr>
						
						<div class="clearfix">
							<!-- PAGINATION -->
							<ul class="pagination">
								<li><a href="javascript:void(0);" >1</a></li>
								<li><a href="javascript:void(0);" >2</a></li>
								<li class="active"><a href="javascript:void(0);" >3</a></li>
								<li><a href="javascript:void(0);" >4</a></li>
								<li><a href="javascript:void(0);" >5</a></li>
								<li><a href="javascript:void(0);" >6</a></li>
								<li><a href="javascript:void(0);" >...</a></li>
							</ul><!-- //PAGINATION -->
							
							<a class="show_all_tovar" href="javascript:void(0);" >show all</a>
							
						</div>
						
						<hr>
						
						
					</div><!-- //SHOP PRODUCTS -->
				</div><!-- //ROW -->
			</div><!-- //CONTAINER -->
		</section><!-- //SHOP -->
		
	
		
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.sticky.js" type="text/javascript"></script>
	<script src="js/parallax.js" type="text/javascript"></script>
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/jquery.jcarousel.js" type="text/javascript"></script>
	<script src="js/jqueryui.custom.min.html" type="text/javascript"></script>
	<script src="js/fancySelect.js"></script>
	<script src="js/animate.js" type="text/javascript"></script>
	<script src="js/myscript.js" type="text/javascript"></script>
	
</body>

<!-- Mirrored from demo.evatheme.com/html/glammy/women.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Aug 2017 08:04:41 GMT -->
</html>