<?php
    session_start();  
    include './conn1.php';
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
    $id=$_REQUEST['id'];
    $sql="update used_item set status=2 where used_item_id='$id'";
//    echo $sql;
    $results=mysqli_query($con,$sql);
    if($results>0)
        {
?>
            <script>
                    window.location="viewaddeditems.php";
                    alert("Added");
            </script>

<?php
        }
        else{
            echo "Can not Add";
            header("location:viewuseditems.php");
        }
?>

