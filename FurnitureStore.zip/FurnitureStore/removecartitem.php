<?php
    session_start();
    include './conn1.php';  
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }
    $id=$_REQUEST['cart_id'];
    $sql="update cart set status=0 where c_id='$id'";
    $results=mysqli_query($con,$sql);
    if($results>0)
        {
?>
            <script>
                    window.location="cart.php";
                    alert("Removed");
            </script>

<?php
        }
        else{
           
 ?>
            <script>
                    window.location="cart.php";
                    alert("Removed");
            </script>
<?php
        }
?>

